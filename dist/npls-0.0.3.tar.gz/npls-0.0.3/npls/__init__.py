from .npls import (npls)

__author__ = ['Andrey Ferubko','Ivan Krylov']
__version__ = '0.0.3'
__email__ = 'ferubko1999@yandex.ru'